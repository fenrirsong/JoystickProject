The Zaber Core Serial Library in C#
===================================
1.2

Thanks for choosing to use a Zaber device! This library is intended to help 
a software project in any .NET language communicate with Zaber devices quickly
and easily. Though the library was written in C#, it is distributed as a
compiled DLL which can be used from any .NET language. In addition, this
package contains a program database (pdb) file for debugging, and in-line
documentation in XML for Visual Studio's IntelliSense. 

Usage & Documentation
=====================
Full documentation and example code can be found online at
http://www.zaber.com/support/docs/api/core-csharp/.

Installation
============
This library is distributed as a DLL, which can be imported into Visual Studio
as a reference like all other DLL libraries. 

To import a library into an existing Visual Studio project, open the Solution
Explorer and right-click "References". Choose "Add Reference...", and browse
to the location of the DLL. 

If the .pdb and .xml files provided are in the same directory as the DLL,
they should be automatically detected by Visual Studio. It is recommended that
the library be kept in the same general folder structure as the rest of your
project, in a directory named "lib" or something similar.

License & Source Code
=====================
This API is open-source, and is licensed under the Apache Software License 
Version 2.0. If you would like a copy of the source code, please send an email
to contact@zaber.com. 

See LICENSE.txt for the full license text.

Contact Us
==========
If you need to contact Zaber for any reason, please send an email to
contact@zaber.com. More detailed contact information can be found online at
http://www.zaber.com/contact/. Please do not hesitate to ask us for help with
this library or our devices.

Changelog
=========

1.2
---
* Fixed a bug that would cause ASCII Axis commands to throw exceptions if
  a device had Alert messages enabled.

1.1
---
* Fixed a bug where the device number of a BinaryReply would not be set.
* Changed target runtime to 4.0.
